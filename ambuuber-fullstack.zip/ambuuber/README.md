# 🚑 AmbuUber — Full Stack Setup Guide

## Project Structure
```
ambuuber/
├── backend/
│   ├── server.js
│   ├── models/         User.js, Ambulance.js, Booking.js
│   ├── routes/         auth.js, ambulances.js, bookings.js, payments.js
│   ├── middleware/     auth.js
│   ├── .env.example
│   └── package.json
└── frontend/
    └── index.html      (GitHub Pages এ deploy করো)
```

---

## ── STEP 1: MongoDB Atlas Setup ──────────────────────────────

1. https://mongodb.com/atlas → Free account তৈরি করো
2. New Project → Create Cluster → **M0 Free**
3. Database Access → Add User → username + password লিখে রাখো
4. Network Access → Add IP → **0.0.0.0/0** (allow all)
5. Connect → Drivers → Connection string copy করো:
   ```
   mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/ambuuber
   ```

---

## ── STEP 2: Backend — Render.com Deploy ────────────────────

1. GitHub এ `ambuuber-backend` নামে repo বানাও
2. `backend/` folder এর সব files push করো
3. https://render.com → New → **Web Service**
4. Repo connect করো
5. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
6. Environment Variables add করো:
   ```
   MONGODB_URI = mongodb+srv://...আগেরটা...
   JWT_SECRET  = ambuuber_jwt_secret_2025_change_me
   FRONTEND_URL = https://তোমার-username.github.io
   NODE_ENV    = production
   ```
7. Deploy → URL পাবে: `https://ambuuber-backend.onrender.com`

---

## ── STEP 3: Frontend — GitHub Pages Deploy ─────────────────

1. `frontend/index.html` এ এই line টা update করো:
   ```javascript
   const API = 'https://ambuuber-backend.onrender.com/api';
   ```
2. GitHub এ `ambuuber` নামে repo বানাও
3. `frontend/index.html` → repo তে push করো (`index.html` root এ রাখো)
4. Settings → Pages → Branch: main → Save
5. Site live: `https://তোমার-username.github.io/ambuuber`

---

## ── API Endpoints ────────────────────────────────────────────

### Auth
| Method | Endpoint           | Description         |
|--------|--------------------|---------------------|
| POST   | /api/auth/register | New user register   |
| POST   | /api/auth/login    | Login               |
| GET    | /api/auth/me       | Current user (JWT)  |

### Ambulances
| Method | Endpoint                      | Auth    |
|--------|-------------------------------|---------|
| GET    | /api/ambulances               | Public  |
| GET    | /api/ambulances/my            | Owner   |
| GET    | /api/ambulances/dashboard     | Owner   |
| POST   | /api/ambulances               | Owner   |
| PATCH  | /api/ambulances/:id/status    | Owner   |
| DELETE | /api/ambulances/:id           | Owner   |

### Bookings
| Method | Endpoint                  | Auth    |
|--------|---------------------------|---------|
| POST   | /api/bookings             | Patient |
| GET    | /api/bookings/my          | Patient |
| GET    | /api/bookings/:id         | Both    |
| PATCH  | /api/bookings/:id/complete| Owner   |
| PATCH  | /api/bookings/:id/cancel  | Patient |

### Payments (Mock)
| Method | Endpoint               | Auth    |
|--------|------------------------|---------|
| POST   | /api/payments/initiate | Patient |
| POST   | /api/payments/verify   | Patient |

---

## ── Local Development ────────────────────────────────────────

```bash
# Backend
cd backend
cp .env.example .env   # .env এ MongoDB URI বসাও
npm install
npm run dev            # http://localhost:5000

# Frontend
# frontend/index.html এ: const API = 'http://localhost:5000/api';
# VS Code Live Server দিয়ে open করো
```

---

## ── Features ─────────────────────────────────────────────────

✅ User Registration & Login (JWT)
✅ Patient & Owner roles
✅ Ambulance listing with filters (ICU/AC/Basic/Oxygen)
✅ Equipment-based filtering
✅ Real booking saved to MongoDB
✅ 50% advance + 50% on arrival payment flow
✅ bKash / Nagad / Rocket mock payment
✅ Receipt generation with unique receipt number
✅ Owner Dashboard with stats
✅ Add/Remove ambulances
✅ Update ambulance status (available/on-trip)
✅ Recent bookings table
✅ Leaflet map with live markers
✅ Works offline with demo data (backend এ API না থাকলেও)
✅ Mobile responsive

---

## ── Production Note (bKash Real API) ───────────────────────

Real bKash integration এর জন্য:
1. https://developer.bka.sh/ → Sandbox account
2. `backend/routes/payments.js` এর mock section replace করো
3. bKash দেয় App Key, App Secret, Username, Password

---

Made with ❤️ for Bangladesh · AmbuUber 2025
