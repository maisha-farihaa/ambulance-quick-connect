const express   = require('express');
const Ambulance = require('../models/Ambulance');
const Booking   = require('../models/Booking');
const { protect, ownerOnly } = require('../middleware/auth');

const router = express.Router();

// GET /api/ambulances  — public, with filters
router.get('/', async (req, res) => {
  try {
    const { type, oxygen, ventilator, ac, status } = req.query;
    const filter = { isApproved: true };

    if (type)       filter.type   = type;
    if (status)     filter.status = status;
    if (oxygen      === 'true') filter['equipment.oxygen']     = true;
    if (ventilator  === 'true') filter['equipment.ventilator'] = true;
    if (ac          === 'true') filter['equipment.ac']         = true;

    const ambulances = await Ambulance.find(filter)
      .populate('owner', 'name phone')
      .sort({ rating: -1 });

    res.json({ success: true, count: ambulances.length, ambulances });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/ambulances/my  — owner's own ambulances
router.get('/my', protect, ownerOnly, async (req, res) => {
  try {
    const ambulances = await Ambulance.find({ owner: req.user._id });
    res.json({ success: true, ambulances });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/ambulances/dashboard  — owner stats
router.get('/dashboard', protect, ownerOnly, async (req, res) => {
  try {
    const ambulances = await Ambulance.find({ owner: req.user._id });
    const ids = ambulances.map(a => a._id);

    const totalBookings   = await Booking.countDocuments({ ambulance: { $in: ids } });
    const activeBookings  = await Booking.countDocuments({ ambulance: { $in: ids }, status: { $in: ['confirmed','dispatched'] } });
    const completedBookings = await Booking.countDocuments({ ambulance: { $in: ids }, status: 'completed' });

    const earned = ambulances.reduce((sum, a) => sum + (a.totalEarned || 0), 0);

    const recentBookings = await Booking.find({ ambulance: { $in: ids } })
      .populate('patient', 'name phone')
      .populate('ambulance', 'name plate')
      .sort({ createdAt: -1 })
      .limit(10);

    res.json({
      success: true,
      stats: {
        totalAmbulances: ambulances.length,
        totalBookings,
        activeBookings,
        completedBookings,
        totalEarned: earned,
      },
      ambulances,
      recentBookings,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/ambulances  — owner adds ambulance
router.post('/', protect, ownerOnly, async (req, res) => {
  try {
    const amb = await Ambulance.create({ ...req.body, owner: req.user._id });
    res.status(201).json({ success: true, ambulance: amb });
  } catch (err) {
    res.status(400).json({ success: false, message: err.message });
  }
});

// PATCH /api/ambulances/:id/status  — owner updates status
router.patch('/:id/status', protect, ownerOnly, async (req, res) => {
  try {
    const amb = await Ambulance.findOneAndUpdate(
      { _id: req.params.id, owner: req.user._id },
      { status: req.body.status },
      { new: true }
    );
    if (!amb) return res.status(404).json({ success: false, message: 'Ambulance not found.' });
    res.json({ success: true, ambulance: amb });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// DELETE /api/ambulances/:id
router.delete('/:id', protect, ownerOnly, async (req, res) => {
  try {
    await Ambulance.findOneAndDelete({ _id: req.params.id, owner: req.user._id });
    res.json({ success: true, message: 'Ambulance removed.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
