const express   = require('express');
const Booking   = require('../models/Booking');
const Ambulance = require('../models/Ambulance');
const { protect, ownerOnly } = require('../middleware/auth');

const router = express.Router();

// POST /api/bookings  — patient creates booking after payment
router.post('/', protect, async (req, res) => {
  try {
    const {
      ambulanceId, pickup, destination, notes,
      requiredEquipment, paymentMethod, transactionId, contactPhone,
    } = req.body;

    const amb = await Ambulance.findById(ambulanceId);
    if (!amb)             return res.status(404).json({ success: false, message: 'Ambulance not found.' });
    if (amb.status !== 'available')
                          return res.status(400).json({ success: false, message: 'Ambulance not available.' });

    const totalPrice   = amb.price;
    const advancePaid  = Math.round(totalPrice * 0.5);
    const remainingDue = totalPrice - advancePaid;

    const booking = await Booking.create({
      patient: req.user._id,
      ambulance: ambulanceId,
      pickup, destination, notes,
      requiredEquipment: requiredEquipment || [],
      totalPrice, advancePaid, remainingDue,
      paymentMethod, transactionId, contactPhone,
      eta: amb.eta || '~10 min',
    });

    // Mark ambulance as on-trip
    await Ambulance.findByIdAndUpdate(ambulanceId, { status: 'on-trip' });

    await booking.populate(['patient', { path: 'ambulance', populate: { path: 'owner', select: 'name phone' } }]);

    res.status(201).json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/bookings/my  — patient's own bookings
router.get('/my', protect, async (req, res) => {
  try {
    const bookings = await Booking.find({ patient: req.user._id })
      .populate('ambulance', 'name type plate driver driverPhone')
      .sort({ createdAt: -1 });
    res.json({ success: true, bookings });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/bookings/:id  — single booking receipt
router.get('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate('patient', 'name phone')
      .populate({ path: 'ambulance', populate: { path: 'owner', select: 'name phone' } });

    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found.' });

    // Only the patient or ambulance owner can view
    const isPatient = booking.patient._id.toString() === req.user._id.toString();
    const isOwner   = booking.ambulance.owner._id.toString() === req.user._id.toString();
    if (!isPatient && !isOwner)
      return res.status(403).json({ success: false, message: 'Access denied.' });

    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH /api/bookings/:id/complete  — owner marks trip as done
router.patch('/:id/complete', protect, ownerOnly, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id).populate('ambulance');
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found.' });

    booking.status        = 'completed';
    booking.paymentStatus = 'fully_paid';
    await booking.save();

    // Update ambulance stats
    await Ambulance.findByIdAndUpdate(booking.ambulance._id, {
      status: 'available',
      $inc: { totalTrips: 1, totalEarned: booking.totalPrice },
    });

    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PATCH /api/bookings/:id/cancel
router.patch('/:id/cancel', protect, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    if (!booking) return res.status(404).json({ success: false, message: 'Booking not found.' });
    if (booking.patient.toString() !== req.user._id.toString())
      return res.status(403).json({ success: false, message: 'Access denied.' });
    if (booking.status !== 'confirmed')
      return res.status(400).json({ success: false, message: 'Cannot cancel this booking.' });

    booking.status        = 'cancelled';
    booking.paymentStatus = 'refunded';
    await booking.save();

    await Ambulance.findByIdAndUpdate(booking.ambulance, { status: 'available' });
    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
