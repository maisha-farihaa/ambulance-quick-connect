const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

/**
 * POST /api/payments/initiate
 * Simulates payment gateway initiation.
 * In production: integrate bKash Payment Gateway API / Nagad API.
 *
 * bKash real docs: https://developer.bka.sh/docs
 * Nagad real docs: https://nagad.com.bd/developer
 */
router.post('/initiate', protect, async (req, res) => {
  try {
    const { method, amount, phone } = req.body;

    if (!method || !amount || !phone) {
      return res.status(400).json({ success: false, message: 'method, amount, phone required.' });
    }

    const validMethods = ['bKash', 'Nagad', 'Rocket'];
    if (!validMethods.includes(method)) {
      return res.status(400).json({ success: false, message: 'Invalid payment method.' });
    }

    // ── Mock payment response (replace with real API call in production) ──
    // For bKash sandbox: POST https://tokenized.sandbox.bka.sh/v1.2.0-beta/tokenized/checkout/payment/create
    const mockTransactionId = method.toUpperCase() + '-' + Date.now() + '-' + Math.floor(Math.random() * 90000 + 10000);

    // Simulate slight delay like a real gateway
    await new Promise(resolve => setTimeout(resolve, 500));

    res.json({
      success: true,
      transactionId: mockTransactionId,
      method,
      amount,
      phone,
      status: 'SUCCESS',
      message: `৳${amount} payment via ${method} successful.`,
      timestamp: new Date().toISOString(),
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

/**
 * POST /api/payments/verify
 * Verify a transaction ID (mock).
 * In production: call bKash/Nagad verify endpoint.
 */
router.post('/verify', protect, async (req, res) => {
  try {
    const { transactionId } = req.body;
    if (!transactionId) return res.status(400).json({ success: false, message: 'transactionId required.' });

    // Mock: any transactionId starting with known prefixes is valid
    const isValid = /^(BKASH|NAGAD|ROCKET)-\d+-\d+$/.test(transactionId);

    res.json({
      success: true,
      transactionId,
      verified: isValid,
      message: isValid ? 'Transaction verified.' : 'Invalid transaction.',
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
