const mongoose = require('mongoose');

const bookingSchema = new mongoose.Schema({
  patient:   { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  ambulance: { type: mongoose.Schema.Types.ObjectId, ref: 'Ambulance', required: true },

  pickup:      { type: String, required: true },
  destination: { type: String, default: '' },
  notes:       { type: String, default: '' },

  requiredEquipment: [String],

  totalPrice:   { type: Number, required: true },
  advancePaid:  { type: Number, required: true },   // 50% upfront
  remainingDue: { type: Number, required: true },   // 50% on arrival

  paymentMethod: { type: String, enum: ['bKash', 'Nagad', 'Rocket'], required: true },
  paymentStatus: { type: String, enum: ['advance_paid', 'fully_paid', 'refunded'], default: 'advance_paid' },
  transactionId: { type: String, default: '' },

  status: {
    type: String,
    enum: ['confirmed', 'dispatched', 'arrived', 'completed', 'cancelled'],
    default: 'confirmed',
  },

  contactPhone: { type: String, required: true },
  eta:          { type: String, default: '' },
  receiptNo:    { type: String, unique: true },
}, { timestamps: true });

// Auto-generate receipt number before save
bookingSchema.pre('save', function (next) {
  if (!this.receiptNo) {
    this.receiptNo = 'AMB-' + Date.now().toString().slice(-8) + '-' + Math.floor(Math.random() * 1000);
  }
  next();
});

module.exports = mongoose.model('Booking', bookingSchema);
