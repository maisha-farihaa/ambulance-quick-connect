const mongoose = require('mongoose');

const ambulanceSchema = new mongoose.Schema({
  owner:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  name:        { type: String, required: true, trim: true },
  area:        { type: String, required: true },
  type:        { type: String, enum: ['Basic Ambulance', 'AC Ambulance', 'ICU Ambulance'], required: true },
  plate:       { type: String, required: true, unique: true, uppercase: true },
  driver:      { type: String, required: true },
  driverPhone: { type: String, required: true },
  price:       { type: Number, required: true },
  rating:      { type: Number, default: 5.0, min: 1, max: 5 },
  ratingCount: { type: Number, default: 0 },

  equipment: {
    oxygen:     { type: Boolean, default: false },
    ventilator: { type: Boolean, default: false },
    defib:      { type: Boolean, default: false },
    monitor:    { type: Boolean, default: false },
    stretcher:  { type: Boolean, default: true },
    ac:         { type: Boolean, default: false },
  },

  status: {
    type: String,
    enum: ['available', 'on-trip', 'offline'],
    default: 'available',
  },

  location: {
    lat: { type: Number, default: 23.7461 },
    lng: { type: Number, default: 90.3842 },
  },

  isApproved: { type: Boolean, default: false },
  totalTrips: { type: Number, default: 0 },
  totalEarned: { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Ambulance', ambulanceSchema);
